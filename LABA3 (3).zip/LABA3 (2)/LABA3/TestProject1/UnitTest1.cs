using NUnit.Framework;
using System.IO;
using System;


namespace TestLaba1
{
    public class Tests
    {

        [SetUp]
        public void Setup()
        {

        }

        [Test]
        [TestCase("6", "0,6741998624632421")]
        [Category("i")]
        public void proverka_vvoda(string x, string expected)
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                LABA3.Program.Calc("6");
                var result = sw.ToString().Trim();
                Assert.IsTrue("6" != null);
                //Assert.AreEqual(expected, result);
            }
        }

    }
}