﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Windows.Automation;
using System.Threading;
using Automation = System.Windows.Automation;
using System.Diagnostics;


namespace LABA3
{
    public class Program
    {
        public static Thread autoThread;
        public static void Calc(string x)
        {
            Console.WriteLine("Begin calculating");
            try
            {
                Process p = Process.Start("calc");
                AutomationElement aeDesktop = AutomationElement.RootElement;
                AutomationElement aeForm = null;
                
                    int chislo = 0;
                    chislo = Convert.ToInt32(x);
                    if (chislo < 10 && chislo >= 0)
                    {
                    ClickButton(x, aeDesktop);
                    ClickButton("Сложение", aeDesktop);
                    ClickButton("5", aeDesktop);
                    ClickButton("Равно", aeDesktop);
                    ClickButton("Добавление памяти", aeDesktop);
                    ClickButton(x, aeDesktop);
                    ClickButton("Вычитание", aeDesktop);
                    ClickButton("1", aeDesktop);
                    ClickButton("Деление", aeDesktop);
                    ClickButton("Вызов из памяти", aeDesktop);
                    ClickButton("Равно", aeDesktop);
                    ClickButton("Очистка памяти", aeDesktop);
                    ClickButton("Добавление памяти", aeDesktop);
                    ClickButton("Вызов из памяти", aeDesktop);
                    ClickButton("Квадратный корень", aeDesktop);
                    ClickButton("Очистка памяти", aeDesktop);

                    GetResult(aeDesktop);

                }
                    else Console.WriteLine("Требуется число от 0 до 10");

                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
        public static void ClickButton(string button, AutomationElement aeDesktop)
        {
            if (aeDesktop != null)
            {

                Thread.Sleep(100);
                Automation.Condition condition = new PropertyCondition(AutomationElement.NameProperty, "Калькулятор");

                Console.Write("Searching for Calculator Window...\n");
                Thread.Sleep(100);
                AutomationElement appElement = aeDesktop.FindFirst(TreeScope.Children, condition);
                if (appElement != null)
                {
                    Console.Write("OK.\n");

                    // Thread.Sleep(1000);

                    Automation.Condition frame = new PropertyCondition(AutomationElement.ClassNameProperty, "CalcFrame");

                    // Thread.Sleep(1000);
                    Console.Write("Searching calc frame...\n");
                    AutomationElement c_frame = appElement.FindFirst(TreeScope.Children, frame);

                    if (c_frame != null)
                    {
                        Automation.Condition butt = new PropertyCondition(AutomationElement.NameProperty, button);
                        Console.Write("Searching " + button + "..\n");
                        AutomationElement but_sev = c_frame.FindFirst(TreeScope.Children, butt);
                        if (but_sev != null)
                        {
                            InvokePattern btnSevenPattern = but_sev.GetCurrentPattern(InvokePattern.Pattern) as InvokePattern;
                            Console.Write("Clicking the " + button + " button\n");
                            btnSevenPattern.Invoke();

                            Console.Write("OK.\n");
                            

                        }
                        else
                        {
                            Console.Write("Error\n");
                        }
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            string x;
            while (true)
            {
                x = Console.ReadLine();
                Calc(x);
                
            }
        }
        public static void GetResult(AutomationElement aeDesktop)
        {
            if (aeDesktop != null)
            {

                Thread.Sleep(100);
                Automation.Condition condition = new PropertyCondition(AutomationElement.NameProperty, "Калькулятор");

                Console.Write("Searching for Calculator Window...\n");
                Thread.Sleep(100);
                AutomationElement appElement = aeDesktop.FindFirst(TreeScope.Children, condition);
                if (appElement != null)
                {
                    Console.Write("OK.\n");

                    // Thread.Sleep(1000);

                    Automation.Condition frame = new PropertyCondition(AutomationElement.ClassNameProperty, "CalcFrame");

                    // Thread.Sleep(1000);
                    Console.Write("Searching calc frame...\n");
                    AutomationElement c_frame = appElement.FindFirst(TreeScope.Children, frame);

                    if (c_frame != null)
                    {
                        
                        Automation.Condition butt = new PropertyCondition(AutomationElement.ClassNameProperty, "Static");
                        AutomationElement but_sev = c_frame.FindFirst(TreeScope.Children, butt);
                        if (but_sev != null)
                        {
                            Automation.Condition butt1 = new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Text);
                            AutomationElement but_sebv = but_sev.FindFirst(TreeScope.Children, butt1);
                            if(but_sebv != null)
                            {
                                Console.WriteLine("Pass\n");
                                ValuePattern btnSevenPattern = but_sev.GetCurrentPattern(ValuePattern.Pattern) as ValuePattern;
                                //Console.Write("Clicking the " + button + " button\n");
                                btnSevenPattern.SetValue("US");
                                Console.Write("333333\n");
                            }
                            

                            Console.Write("OK.\n");


                        }
                        else
                        {
                            Console.Write("Fail\n");
                        }
                    }
                }
            }
            
        }
    }
}

